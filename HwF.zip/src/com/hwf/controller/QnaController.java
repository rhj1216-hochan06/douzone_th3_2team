package com.hwf.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hwf.dao.QnaDAO;
import com.hwf.model.QnaDTO;


@WebServlet("/board")
public class QnaController extends HttpServlet {
	
	public QnaController() { }
	
	public void service(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); // 한글로 데이터를 받고 내려가야함 
		
		String cmd = request.getParameter("cmd");  //  ~~?cmd=list
		System.out.println("cmd : " + cmd);
		
		if( cmd.equals("list") ) {			
			list(request, response);
		} else if( cmd.equals("write") ) {			
			write(request, response);
		} 
	} // service end

	public void list(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		QnaDAO dao = new QnaDAO();
		List<QnaDTO>  list = dao.selectAll();
		
		if( list != null ) {
			request.setAttribute("list", list);  // data save
			request.getRequestDispatcher("views/list.jsp").forward(request, response);
		} else {
			response.sendRedirect("views/error.jsp");
		}
	} // list end
	
	
	
	
	  public void write(HttpServletRequest request, HttpServletResponse response)
	  throws ServletException, IOException {
	  
	  
	  request.setCharacterEncoding("UTF-8"); 
	  String memberid = request.getParameter("memberid"); 
	  String qnacontent = request.getParameter("qnacontent"); 
	  String qnaanswer = request.getParameter("qnaanswer");
	  
	 
	  System.out.println(qnacontent + ",\t" + qnaanswer +",\t" + memberid +",\t");
	  
	  QnaDAO dao = new QnaDAO(); 
	  QnaDTO dto = new QnaDTO(qnacontent, qnaanswer, memberid);
	  
	 int rowcount = dao.insert(dto); if( rowcount > 0 ) { //

	 response.sendRedirect("board?cmd=list"); 
	 } else {
	 response.sendRedirect("views/error.jsp"); } 
	 } // write end
	 
}
