function heatlhpolicy(){
            if($('#heatlhpolicy').css('display') == 'none'){
            $('#heatlhpolicy').show();
        }else{
            $('#heatlhpolicy').hide();
        }
        }